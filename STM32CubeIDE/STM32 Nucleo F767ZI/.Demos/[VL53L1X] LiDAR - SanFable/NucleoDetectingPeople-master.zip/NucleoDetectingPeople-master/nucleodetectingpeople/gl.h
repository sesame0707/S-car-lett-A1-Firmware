/*********************************************************************
*               SEGGER MICROCONTROLLER GmbH & Co. KG                 *
*       Solutions for real time microcontroller applications         *
**********************************************************************
*                                                                    *
*       (c) 2002 - 2015  SEGGER Microcontroller GmbH & Co. KG        *
*                                                                    *
*       www.segger.com     Support: support@segger.com               *
*                                                                    *
**********************************************************************
 
----------------------------------------------------------------------
File    : gl.h
Purpose : Automatically created from gui.bmp using Bin2C.exe
--------  END-OF-HEADER  ---------------------------------------------
*/

#ifndef __GL_H__
#define __GL_H__

#define GL_SIZE 391734

extern const unsigned char gl_file[391734];

#endif  //__GL_H__

/****** End Of File *************************************************/
