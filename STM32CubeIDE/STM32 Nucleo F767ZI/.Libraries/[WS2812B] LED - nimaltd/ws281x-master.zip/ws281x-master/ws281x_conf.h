#ifndef _WS281X_CONF_H_
#define _WS281X_CONF_H_

#define	WS281X_FREERTOS					1

#endif
